## ------------------------------------------------------------------------
library(vcfR)

vcf_file <- system.file("extdata", "pinf_sc50.vcf.gz", package = "pinfsc50")
dna_file <- system.file("extdata", "pinf_sc50.fasta", package = "pinfsc50")
gff_file <- system.file("extdata", "pinf_sc50.gff", package = "pinfsc50")

vcf <- read.vcf(vcf_file, verbose = FALSE)
dna <- ape::read.dna(dna_file, format = "fasta")
gff <- read.table(gff_file, sep="\t", quote="")

chrom <- create.chromR(name="Supercontig", vcf=vcf, seq=dna, ann=gff, verbose=TRUE)
chrom <- masker(chrom, min_QUAL = 1, min_DP = 300, max_DP = 700, min_MQ = 59.9,  max_MQ = 60.1)
chrom <- proc.chromR(chrom, verbose = TRUE)


## ------------------------------------------------------------------------
head(chrom)

## ---- tidy=TRUE----------------------------------------------------------
strwrap(grep("DP", chrom@vcf@meta, value=T))

## ---- fig.height=7, fig.width=7------------------------------------------
dp <- extract.gt(chrom, element="DP", as.numeric=TRUE)
plot(rowSums(dp), chrom@var.info$DP)
abline(a=0, b=1)

## ---- fig.height=7, fig.width=7------------------------------------------
gq <- extract.gt(chrom, element="GQ", as.numeric=TRUE)
plot(rowSums(dp), rowSums(gq), pch=20, col="#0000ff22")
#plot(rowSums(dp[chrom@var.info$mask,]), rowSums(gq[chrom@var.info$mask,]), pch=20, col="#0000ff22")
abline(a=0, b=1)
abline(v=700, lty=2)

## ------------------------------------------------------------------------
strwrap(grep("MQ", chrom@vcf@meta, value=T))
strwrap(grep("DP,", chrom@vcf@meta, value=T))

## ------------------------------------------------------------------------
chrom@var.info$DP <- rowSums(dp)

## ---- fig.height=7, fig.width=7------------------------------------------
plot(chrom)

## ---- fig.height=7, fig.width=7------------------------------------------
chrom <- masker(chrom, min_QUAL=0, min_DP=300, max_DP=650, min_MQ=59, max_MQ=61)
plot(chrom)

## ---- fig.height=7, fig.width=7------------------------------------------
chromoqc(chrom, verbose=FALSE)

## ---- fig.height=7, fig.width=7------------------------------------------
#chrom <- masker(chrom, QUAL = 999, mindp = 0.25, maxdp = 0.99,
#                  minmq = 43, maxmq = 50)
#plot(chrom)

## ---- fig.height=7, fig.width=7------------------------------------------
#chromoqc(chrom, verbose=FALSE)

## ---- eval=FALSE---------------------------------------------------------
#  write.vcf(chrom, file="good_variants.vcf", mask=TRUE)

