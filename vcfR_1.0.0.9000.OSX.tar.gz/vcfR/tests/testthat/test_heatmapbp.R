
# Heatmap.bp tests.

# detach(package:vcfR, unload=T)
library(vcfR)
context("heatmap.bp functions")

#library(testthat)
#data(vcfR_example)

x  <- as.matrix(mtcars)

test_that("we can create null a Chrom",{
#  heatmap.bp(x)
#  heatmap.bp(x, scale="col")
})
