## ------------------------------------------------------------------------
library(vcfR)
#vcf_file <- system.file("extdata", "pinf_sc1_100_sub.vcf.gz", package = "vcfR")
#seq_file <- system.file("extdata", "pinf_sc100.fasta", package = "vcfR")
#gff_file <- system.file("extdata", "pinf_sc100.gff", package = "vcfR")

vcf_file <- system.file("extdata", "pinf_sc50.vcf.gz", package = "pinfsc50")
dna_file <- system.file("extdata", "pinf_sc50.fasta", package = "pinfsc50")
gff_file <- system.file("extdata", "pinf_sc50.gff", package = "pinfsc50")

vcf <- read.vcf(vcf_file, verbose = FALSE)
dna <- ape::read.dna(dna_file, format = "fasta")
gff <- read.table(gff_file, sep="\t", quote = "")

chrom <- create.chromR(name="Supercontig_1.100", vcf=vcf, seq=dna, ann=gff, verbose=TRUE)
chrom <- masker(chrom, min_DP = 900, max_DP = 1500)
chrom <- proc.chromR(chrom, verbose = TRUE)


## ------------------------------------------------------------------------
head(chrom)

## ------------------------------------------------------------------------
dp <- extract.gt(chrom, element="DP", as.numeric=TRUE)
gq <- extract.gt(chrom, element="GQ", as.numeric=TRUE)

## ---- fig.align='center'-------------------------------------------------
hist(gq[,1])

## ---- fig.height=7, fig.width=7------------------------------------------
heatmap.bp(gq)

## ------------------------------------------------------------------------
apply(gq, MARGIN=2, range, na.rm=TRUE)

## ------------------------------------------------------------------------
dpz <- z.score(dp)
dpz <- abs(dpz)
maxes <- apply(dpz, MARGIN=2, max, na.rm=TRUE)
dp2 <- abs(sweep(dpz, MARGIN = 2, STATS = maxes, FUN = "-"))
dp2 <- 100 * sweep(dp2, MARGIN = 2, STATS = maxes, FUN = "/")

## ------------------------------------------------------------------------
apply(dp2, MARGIN=2, range)

## ---- fig.height=7, fig.width=7------------------------------------------
heatmap.bp(dp2)

## ---- fig.align='center'-------------------------------------------------
scores <- rowMeans(dp2) + rowMeans(gq)
is.na(scores[c(7,10)]) <- TRUE

## ---- fig.align='center'-------------------------------------------------
hist(scores)

## ------------------------------------------------------------------------
chrom <- masker(chrom)
chrom <- rank.variants.chromR(chrom, scores)
head(chrom@var.info)

## ------------------------------------------------------------------------
cbind(chrom@var.info[1:26, c('POS', 'mask', 'window_number', 'rank')], scores[1:26])

## ------------------------------------------------------------------------
chrom@var.info$mask[chrom@var.info$rank > 1] <- FALSE

## ---- fig.height=7, fig.width=7------------------------------------------
chromoqc(chrom, dot.alpha='ff')

## ------------------------------------------------------------------------
chrom@var.info$mask[chrom@var.info$MQ < 42] <- FALSE

## ---- fig.height=7, fig.width=7------------------------------------------
chromoqc(chrom, dot.alpha='ff')

