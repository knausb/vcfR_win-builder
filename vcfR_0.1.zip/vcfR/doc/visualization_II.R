## ------------------------------------------------------------------------
library(vcfR)
#vcf_file <- system.file("extdata", "pinf_sc1_100_sub.vcf.gz", package = "vcfR")
#seq_file <- system.file("extdata", "pinf_sc100.fasta", package = "vcfR")
#gff_file <- system.file("extdata", "pinf_sc100.gff", package = "vcfR")

vcf_file <- system.file("extdata", "pinf_sc50.vcf.gz", package = "pinfsc50")
dna_file <- system.file("extdata", "pinf_sc50.fasta", package = "pinfsc50")
gff_file <- system.file("extdata", "pinf_sc50.gff", package = "pinfsc50")

vcf <- read.vcf(vcf_file, verbose = FALSE)
dna <- ape::read.dna(dna_file, format = "fasta")
gff <- read.table(gff_file, sep="\t")

chrom <- create.chromR(name="Supercontig_1.100", vcf=vcf, seq=dna, ann=gff, verbose=TRUE)
chrom <- masker(chrom, min_DP = 300, max_DP = 700)
chrom <- proc.chromR(chrom, verbose = TRUE)


## ------------------------------------------------------------------------
head(chrom)

## ------------------------------------------------------------------------
dp <- extract.gt(chrom, element="DP", as.numeric=TRUE)
rownames(dp) <- 1:nrow(dp)
head(dp)

## ---- fig.height=7, fig.width=7------------------------------------------
heatmap.bp(dp)

## ------------------------------------------------------------------------
is.na(dp[na.omit(dp == 0)]) <- TRUE

## ---- fig.height=7, fig.width=7------------------------------------------
heatmap.bp(dp)

## ---- fig.height=4, fig.width=7------------------------------------------
par(mar=c(8,4,4,2))
barplot(apply(dp, MARGIN=2, mean, na.rm=TRUE), las=3)
par(mar=c(5,4,4,2))

## ---- fig.height=7, fig.width=7------------------------------------------
dpw <- windowize.NM(dp, pos=chrom@var.info$POS, starts=chrom@win.info$start,
                    ends=chrom@win.info$end)
dpw[is.na(dpw)] <- 0
is.na(dpw[dpw==0]) <- TRUE
heatmap.bp(dpw)

