## ---- eval=FALSE---------------------------------------------------------
#  vignette("intro_to_vcfR", package="vcfR")

## ------------------------------------------------------------------------
library(vcfR)
#vcf_file <- system.file("extdata", "pinf_sc1_100_sub.vcf.gz", package = "vcfR")
#seq_file <- system.file("extdata", "pinf_sc100.fasta", package = "vcfR")
#gff_file <- system.file("extdata", "pinf_sc100.gff", package = "vcfR")

vcf_file <- system.file("extdata", "pinf_sc50.vcf.gz", package = "pinfsc50")
dna_file <- system.file("extdata", "pinf_sc50.fasta", package = "pinfsc50")
gff_file <- system.file("extdata", "pinf_sc50.gff", package = "pinfsc50")


vcf <- read.vcf(vcf_file, verbose = FALSE)
dna <- ape::read.dna(dna_file, format = "fasta")
gff <- read.table(gff_file, sep="\t")

chrom <- create.chromR(name="Supercontig_1.100", vcf=vcf, seq=dna, ann=gff, verbose=TRUE)
chrom <- masker(chrom, min_DP = 300, max_DP = 700)
chrom <- proc.chromR(chrom, verbose = TRUE)


## ---- fig.height=7, fig.width=7------------------------------------------
chromoqc(chrom)

## ---- fig.height=7, fig.width=7------------------------------------------
chrom <- proc.chromR(chrom, verbose=FALSE, win.size=1e3)
chromoqc(chrom, verbose=FALSE)

## ------------------------------------------------------------------------
head(chrom)

## ---- fig.height=7, fig.width=7------------------------------------------
plot(chrom)

## ---- fig.height=7, fig.width=7------------------------------------------
plot(chrom@var.info$DP, chrom@var.info$MQ, col="#0000ff66")

## ------------------------------------------------------------------------
cor(chrom@var.info$DP, chrom@var.info$MQ)

